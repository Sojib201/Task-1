String baseUrl = "https://w05.yeapps.com//accl_api/";



var appVersion = '';
String cid = "accl";
String deviceId = "";
String deviceBrand = "";
String deviceModel = "";

String? loginUserId ;
String? loginUserPass ;
String? userName;
String? userMobile ;
String? userUnitId ;
String? customerId ;
String? customerName;
String? invoiceCode;

bool isLocationPermissionEnable = false;


