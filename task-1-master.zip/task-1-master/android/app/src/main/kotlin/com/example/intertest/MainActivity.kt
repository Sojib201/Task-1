package com.example.intertest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
